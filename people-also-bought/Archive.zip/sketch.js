function sum(x, y) {
  return x + y + 42;
}

module.exports = sum;
