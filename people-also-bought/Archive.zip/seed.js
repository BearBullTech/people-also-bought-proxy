module.exports = {
	"undefined": "mongodb://localhost/people-also-bought",
	"dev": "localhost/DEV_DB_NAME",
	"prod": "localhost/PROD_DB_NAME"
}